import csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
from random import sample, randint, random
from statsmodels.tsa.holtwinters import Holt

################# Begin Import the train data1(training data japan1.csv) ##################
with open('training data japan1.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
train_japan1 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the train data2(actual data)(training data japan2.csv) ##############
with open('training data japan2.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
train_japan2 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################



x_max = 1 # The max dimension
x_min = 0 # The min dimension
N=30 # Number of population
D=1 # Dimension

# Generating the populationq
# x = np.random.rand(N, D) * (x_max - x_min) + x_min
# print(x)

############################# Begin SimpleExpSmoothing model ##############################
series = train_japan1 #Define the seasonal data list
n_preds=24
# Define the SimpleExpSmoothing model
def SimpleExp_model(series, alpha, n_preds):
    # 读取时间序列数据
    data = pd.read_csv('training data japan3.csv', parse_dates=['date'], index_col='date')

    # 设置平滑系数
    # alpha = 0.2

    # 初始化预测值为第一个观察值
    data['smoothed'] = data['value'].iloc[0]

    # 计算指数平滑
    for i in range(1, len(data)):
        data['smoothed'].iloc[i] = alpha * data['value'].iloc[i] + (1 - alpha) * data['smoothed'].iloc[i - 1]

    # 打印结果
    # print(data)
    array_forecast = data['smoothed'].tolist()
    # print(array_forecast)
        # Define the dataset as python lists 
    actual   = train_japan2
    forecast = array_forecast
    # Consider a list APE to store the 
    # APE value for each of the records in dataset 
    APE = [] 
     # Iterate over the list values 
    for day in range(24): 

        # Calculate percentage error 
        per_err = (actual[day] - forecast[day]) / actual[day] 

        # Take absolute value of 
        # the percentage error (APE) 
        per_err = abs(per_err) 

        # Append it to the APE list 
        APE.append(per_err) 

    # Calculate the MAPE 
    MAPE = sum(APE)/len(APE)
    # Print the MAPE value and percentage 
    # print(f''' 
    # MAPE   : { round(MAPE, 2) } 
    # MAPE % : { round(MAPE*100, 2) } % 
    # ''')
    return MAPE , forecast
############################# End SimpleExpSmoothing model ##############################


x = np.random.rand(N, D) * (x_max - x_min) + x_min
################### Begin WOA algorithm ###############################
def woaAlgorithm(x, N, D, n_preds):
    # 参数设置
    pop_size = 30
    # dim = 5
    # lower_bound = -10
    # upper_bound = 10
    max_iter = 500

    # # 定义目标函数（可以根据实际问题更改）
    # def objective_function(x):
    #     return np.sum(x**2)
    
    # 定义适应度函数
    def func(x, series, n_preds):
        # print(x)
        alpha=x[0]
        m1=SimpleExp_model(series, alpha, n_preds)
        return m1[0]

    # # 初始化种群
    # def initialize_population(pop_size, dim, lower_bound, upper_bound):
    #     return lower_bound + (upper_bound - lower_bound) * np.random.rand(pop_size, dim)

    # 更新位置
    def update_position(whales, leader, a):
        pop_size, dim = whales.shape
        for i in range(pop_size):
            r1, r2 = np.random.rand(), np.random.rand()
            A = 2 * a * r1 - a
            C = 2 * r2
            p = np.random.rand()
            
            if p < 0.5:
                if abs(A) < 1:
                    D = abs(C * leader - whales[i])
                    whales[i] = leader - A * D
                else:
                    rand_whale = whales[np.random.randint(pop_size)]
                    D = abs(C * rand_whale - whales[i])
                    whales[i] = rand_whale - A * D
            else:
                distance_to_leader = abs(leader - whales[i])
                whales[i] = distance_to_leader * np.exp(2 * (-p)) * np.cos(2 * np.pi * p) + leader
            
            # 确保鲸鱼的位置在边界内
            # whales[i] = np.clip(whales[i], x_max, x_min)
        return whales

    # 鲸鱼优化算法
    def woa(func, pop_size, D, max_iter, x):
        # 初始化种群
        # whales = initialize_population(pop_size, dim, lower_bound, upper_bound)
        whales = x
        # fitness = np.apply_along_axis(objective_function, 1, whales)
        fitness = np.apply_along_axis(func, 1, whales, series, n_preds)
        
        # 找到初始的领导者
        leader_idx = np.argmin(fitness)
        leader = whales[leader_idx]
        
        # 主循环
        for iteration in range(max_iter):
            a = 2 - iteration * (2 / max_iter)  # a 从 2 线性递减到 0
            
            # 更新鲸鱼的位置
            whales = update_position(whales, leader, a)
            
            # 计算新种群的适应度
            fitness = np.apply_along_axis(func, 1, whales, series, n_preds)
            
            # 更新领导者
            current_leader_idx = np.argmin(fitness)
            current_leader = whales[current_leader_idx]
            if fitness[current_leader_idx] < fitness[leader_idx]:
                leader_idx = current_leader_idx
                leader = current_leader
            
            # 打印当前最佳结果
            # print(f"Iteration {iteration + 1}, Best fitness: {fitness[leader_idx]}")
        
        return  fitness[leader_idx],leader
    return woa(func, pop_size, D, max_iter,x)


# 运行鲸鱼优化算法
value = woaAlgorithm(x, N, D, n_preds)
best_position = value[1]
best_fitness = value[0]

#训练集数据储存
trainresults=best_fitness
filename = "TrainResults_WOA_SimpleExp.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)    
    # 检查trainresults是否为可迭代对象（如数组或列表）
    if isinstance(trainresults, (list, np.ndarray)):
        writer.writerow([float(item) for item in trainresults])
    else:
        # 如果trainresults是单个值
        writer.writerow([float(trainresults)])

############################################# Test Data Set#########################################################

################# Begin Import the test data1(test data japan1.csv) ##################
with open('test data japan1.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
test_japan1 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the test data2(actual data)(test data japan2.csv) ##############
with open('test data japan2.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
test_japan2 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

################# Begin Import the test data3(actual data)(test data japan3.csv) ##############
with open('test data japan3.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
test_japan3 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

x_max = 1 # The max dimension
x_min = 0 # The min dimension
N=30 # Number of population
D=1 # Dimension

# Generating the population
# x = np.random.rand(N, D) * (x_max - x_min) + x_min
# print(x)


############################# Begin SimpleExpSmoothing model ##############################
series = test_japan1 #Define the seasonal data list
n_preds=24
# Define the SimpleExpSmoothing model
def test_SimpleExp_model(series, alpha, n_preds):
    # 读取时间序列数据
    data = pd.read_csv('test data japan3.csv', parse_dates=['date'], index_col='date')

    # 设置平滑系数
    # alpha = 0.2

    # 初始化预测值为第一个观察值
    data['smoothed'] = data['value'].iloc[0]

    # 计算指数平滑
    for i in range(1, len(data)):
        data['smoothed'].iloc[i] = alpha * data['value'].iloc[i] + (1 - alpha) * data['smoothed'].iloc[i - 1]

    # 打印结果
    # print(data)
    array_forecast = data['smoothed'].tolist()
    # print(array_forecast)
        # Define the dataset as python lists 
    actual   = test_japan2
    forecast = array_forecast
    # Consider a list APE to store the 
    # APE value for each of the records in dataset 
    APE = [] 
    # Iterate over the list values 
    for day in range(24): 

        # Calculate percentage error 
        per_err = (actual[day] - forecast[day]) / actual[day] 

        # Take absolute value of 
        # the percentage error (APE) 
        per_err = abs(per_err) 

        # Append it to the APE list 
        APE.append(per_err) 

    # Calculate the MAPE 
    MAPE = sum(APE)/len(APE)
    # Print the MAPE value and percentage 
    # print(f''' 
    # MAPE   : { round(MAPE, 2) } 
    # MAPE % : { round(MAPE*100, 2) } % 
    # ''')
    return MAPE , forecast
############################# End SimpleExpSmoothing model ##############################

alpha = best_position
data1 = test_SimpleExp_model(series, alpha, n_preds)

########################################  测试集上的数据储存 ######################################## 
testresults = data1[0]
filename = "TestResults_WOA_SimpleExp.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    # # for row in data2:
    # #     writer.writerow(float(item) for item in row)
    # writer.writerow([float(item) for item in testresults])

    # 检查trainresults是否为可迭代对象（如数组或列表）
    if isinstance(testresults, (list, np.ndarray)):
        writer.writerow([float(item) for item in testresults])
    else:
        # 如果trainresults是单个值
        writer.writerow([float(testresults)])
########################################  测试集上的预测值数据 ######################################## 

data2 = data1[1]
filename = "WOA_SimpleExp.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    # for row in data2:
    #     writer.writerow(float(item) for item in row)
    writer.writerow([float(item) for item in data2])

print(data2)
print(testresults)
