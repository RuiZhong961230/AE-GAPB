import csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
from random import sample, randint, random
from statsmodels.tsa.holtwinters import Holt

# 定义目标函数（可以根据实际问题更改）
def objective_function(x):
    return np.sum(x**2)

# 初始化灰狼种群
def initialize_population(pop_size, dim, lower_bound, upper_bound):
    return lower_bound + (upper_bound - lower_bound) * np.random.rand(pop_size, dim)

# 更新 alpha, beta 和 delta 灰狼
def update_alpha_beta_delta(population, fitness):
    alpha, beta, delta = np.argsort(fitness)[:3]
    return population[alpha], population[beta], population[delta]

# 灰狼优化算法
def gwo(objective_function, pop_size, dim, lower_bound, upper_bound, max_iter):
    # 初始化种群
    population = initialize_population(pop_size, dim, lower_bound, upper_bound)
    fitness = np.apply_along_axis(objective_function, 1, population)
    
    # 初始化 alpha, beta 和 delta 灰狼
    alpha, beta, delta = update_alpha_beta_delta(population, fitness)
    
    # 主循环
    for iteration in range(max_iter):
        a = 2 - 2 * iteration / max_iter  # a 从 2 线性递减到 0
        
        for i in range(pop_size):
            for j in range(dim):
                r1, r2 = np.random.rand(), np.random.rand()
                A1, C1 = 2 * a * r1 - a, 2 * r2
                D_alpha = abs(C1 * alpha[j] - population[i, j])
                X1 = alpha[j] - A1 * D_alpha
                
                r1, r2 = np.random.rand(), np.random.rand()
                A2, C2 = 2 * a * r1 - a, 2 * r2
                D_beta = abs(C2 * beta[j] - population[i, j])
                X2 = beta[j] - A2 * D_beta
                
                r1, r2 = np.random.rand(), np.random.rand()
                A3, C3 = 2 * a * r1 - a, 2 * r2
                D_delta = abs(C3 * delta[j] - population[i, j])
                X3 = delta[j] - A3 * D_delta
                
                population[i, j] = (X1 + X2 + X3) / 3
        
        # 计算新种群的适应度
        fitness = np.apply_along_axis(objective_function, 1, population)
        
        # 更新 alpha, beta 和 delta 灰狼
        alpha, beta, delta = update_alpha_beta_delta(population, fitness)
        
        # 打印当前最佳结果
        print(f"Iteration {iteration + 1}, Best fitness: {fitness.min()}")
    
    return alpha, fitness.min()

# 参数设置
pop_size = 20
dim = 5
lower_bound = -10
upper_bound = 10
max_iter = 100

# 运行灰狼优化算法
best_position, best_fitness = gwo(objective_function, pop_size, dim, lower_bound, upper_bound, max_iter)

print(f"Best position: {best_position}")
print(f"Best fitness: {best_fitness}")
