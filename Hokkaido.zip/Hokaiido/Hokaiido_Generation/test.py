import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 数据导入
data = {
    'date': [
        '200001', '200002', '200003', '200004', '200005', '200006', '200007', '200008', '200009', '200010', '200011', '200012',
        '200101', '200102', '200103', '200104', '200105', '200106', '200107', '200108', '200109', '200110', '200111', '200112',
        '200201', '200202', '200203', '200204', '200205', '200206', '200207', '200208', '200209', '200210', '200211', '200212',
        '200301', '200302', '200303', '200304', '200305', '200306', '200307', '200308', '200309', '200310', '200311', '200312',
        '200401', '200402', '200403', '200404', '200405', '200406', '200407', '200408', '200409', '200410', '200411', '200412',
        '200501', '200502', '200503', '200504', '200505', '200506', '200507', '200508', '200509', '200510', '200511', '200512'
    ],
    'value': [
        18581, 17035, 17896, 16762, 17582, 16537, 16186, 1211, 15090, 18672, 18857, 18990,
        17612, 16233, 16983, 15686, 15069, 14404, 185, 3581, 13222, 14617, 14856, 15472,
        17234, 15315, 16917, 16216, 16385, 9280, 6216, 15335, 15334, 18285, 17356, 18699,
        18196, 15800, 17692, 16883, 16942, 15865, 215, 668, 14253, 14212, 13631, 16139,
        16201, 14765, 15559, 14504, 14496, 7179, 11241, 14547, 14363, 14936, 13584, 15215,
        15320, 13448, 14780, 13983, 14468, 6842, 1736, 15790, 14769, 14914, 13898, 14682
    ]
}

# 创建DataFrame
df = pd.DataFrame(data)

# 手动设置自回归参数ϕ1
phi_1 = 0.5  # 您可以根据需要手动设置该值

# 手动进行预测
def manual_ar1_prediction(data, phi_1, steps):
    predictions = []
    last_value = data[-1]
    for _ in range(steps):
        next_value = phi_1 * last_value
        predictions.append(next_value)
        last_value = next_value
    return predictions

# 预测未来10个时间点
future_steps = 10
manual_predictions = manual_ar1_prediction(df['value'].values, phi_1, future_steps)

# 打印预测结果
print('Manual Predictions:')
print(manual_predictions)

# 绘制预测结果
plt.figure(figsize=(12, 6))
plt.plot(df['date'], df['value'], label='Original Time Series')
future_dates = [str(int(df['date'].values[-1]) + i) for i in range(1, future_steps + 1)]
plt.plot(np.concatenate((df['date'].values, future_dates)), 
         np.concatenate((df['value'].values, manual_predictions)), 
         label='Predicted Values', linestyle='--')
plt.title('Manual AR(1) Model Prediction')
plt.xlabel('Date')
plt.ylabel('Value')
plt.xticks(rotation=90)
plt.legend()
plt.show()
