import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
 
# 生成具有自回归关系的时间序列数据
np.random.seed(42)
n = 100  # 观测值数量
phi = 0.5  # 自回归系数
 
# 生成自回归时间序列数据
ar_data = [0]
for i in range(1, n):
    ar_data.append(phi * ar_data[i-1] + np.random.normal(0, 1))
 
# 绘制生成的时间序列数据
plt.figure(figsize=(10, 6))
plt.plot(ar_data, label='AR(1) Process')
plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Autoregressive (AR) Process')
plt.legend()
plt.grid(True)
plt.show()
 
# 拟合自回归模型
model = sm.tsa.AR(ar_data)
result = model.fit(maxlag=1)  # 这里的maxlag表示自回归的阶数，这里设置为1
 
# 预测未来值
forecast = result.predict(start=len(ar_data), end=len(ar_data) + 10)
 
# 绘制预测结果
plt.figure(figsize=(10, 6))
plt.plot(np.arange(n), ar_data, label='Original Data')
plt.plot(np.arange(n, n+11), np.concatenate(([ar_data[-1]], forecast)), label='Forecast', color='red')
plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Autoregressive (AR) Model Forecast')
plt.legend()
plt.grid(True)
plt.show()