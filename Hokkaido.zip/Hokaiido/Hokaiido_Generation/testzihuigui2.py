import numpy as np
from numpy.random import random as rand
import csv
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
from random import sample, randint, random
from statsmodels.tsa.ar_model import AutoReg
from statsmodels.tsa.arima_process import ArmaProcess
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm

n = 72 
################# Begin Import the train data1(training data japan1.csv) ##################
with open('training data japan1.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
train_japan1 = [float(s) for s in str_array]

# 转换为NumPy数组
data = np.array(train_japan1)

# 创建并拟合AutoReg模型
model = AutoReg(data, lags=1)  # 使用1阶自回归模型
model_fitted = model.fit()

# 输出模型参数
print('Model Coefficients:', model_fitted.params)

# 使用模型进行预测
forecast = model_fitted.predict(start=len(data), end=len(data)+24)

 
# 绘制预测结果
plt.figure(figsize=(10, 6))
plt.plot(np.arange(n), train_japan1 , label='Original Data')
plt.plot(np.arange(n, n+25), np.concatenate(([train_japan1 [-1]], forecast)), label='Forecast', color='red')
plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Autoregressive (AR) Model Forecast')
plt.legend()
plt.grid(True)
plt.show()